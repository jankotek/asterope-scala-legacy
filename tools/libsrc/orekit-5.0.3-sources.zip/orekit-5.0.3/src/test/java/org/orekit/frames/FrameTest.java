/* Copyright 2002-2010 CS Communication & Systèmes
 * Licensed to CS Communication & Systèmes (CS) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * CS licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.orekit.frames;

import java.util.Random;

import org.apache.commons.math.geometry.Rotation;
import org.apache.commons.math.geometry.Vector3D;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.orekit.Utils;
import org.orekit.errors.FrameAncestorException;
import org.orekit.errors.OrekitException;
import org.orekit.time.AbsoluteDate;

public class FrameTest {

    @Test
    public void testSameFrameRoot() throws OrekitException {
        Random random = new Random(0x29448c7d58b95565l);
        Frame  frame  = FramesFactory.getEME2000();
        checkNoTransform(frame.getTransformTo(frame, new AbsoluteDate()), random);
    }

    @Test
    public void testSameFrameNoRoot() throws OrekitException {
        Random random = new Random(0xc6e88d0f53e29116l);
        Transform t   = randomTransform(random);
        Frame frame   = new Frame(FramesFactory.getEME2000(), t, null, true);
        checkNoTransform(frame.getTransformTo(frame, new AbsoluteDate()), random);
    }

    @Test
    public void testSimilarFrames() throws OrekitException {
        Random random = new Random(0x1b868f67a83666e5l);
        Transform t   = randomTransform(random);
        Frame frame1  = new Frame(FramesFactory.getEME2000(), t, null, true);
        Frame frame2  = new Frame(FramesFactory.getEME2000(), t, null, false);
        checkNoTransform(frame1.getTransformTo(frame2, new AbsoluteDate()), random);
    }

    @Test
    public void testFromParent() throws OrekitException {
        Random random = new Random(0xb92fba1183fe11b8l);
        Transform fromEME2000  = randomTransform(random);
        Frame frame = new Frame(FramesFactory.getEME2000(), fromEME2000, null);
        Transform toEME2000 = frame.getTransformTo(FramesFactory.getEME2000(), new AbsoluteDate());
        checkNoTransform(new Transform(fromEME2000, toEME2000), random);
    }

    @Test
    public void testDecomposedTransform() throws OrekitException {
        Random random = new Random(0xb7d1a155e726da57l);
        Transform t1  = randomTransform(random);
        Transform t2  = randomTransform(random);
        Transform t3  = randomTransform(random);
        Frame frame1 =
            new Frame(FramesFactory.getEME2000(), new Transform(new Transform(t1, t2), t3), null);
        Frame frame2 =
            new Frame(new Frame(new Frame(FramesFactory.getEME2000(), t1, null), t2, null), t3, null);
        checkNoTransform(frame1.getTransformTo(frame2, new AbsoluteDate()), random);
    }

    @Test
    public void testFindCommon() throws OrekitException {

        Random random = new Random(0xb7d1a155e726da57l);
        Transform t1  = randomTransform(random);
        Transform t2  = randomTransform(random);
        Transform t3  = randomTransform(random);

        Frame R1 = new Frame(FramesFactory.getEME2000(),t1,"R1");
        Frame R2 = new Frame(R1,t2,"R2");
        Frame R3 = new Frame(R2,t3,"R3");

        Transform T = R1.getTransformTo(R3, new AbsoluteDate());

        Transform S = new Transform(t2,t3);

        checkNoTransform(new Transform(T, S.getInverse()) , random);

    }

    @Test
    public void testIsChildOf() throws OrekitException{
        Random random = new Random(0xb7d1a155e726da78l);
        Frame eme2000 = FramesFactory.getEME2000();

        Frame f1 = new Frame(eme2000, randomTransform(random), "f1");
        Frame f2 = new Frame(f1     , randomTransform(random), "f2");
        Frame f4 = new Frame(f2     , randomTransform(random), "f4");
        Frame f5 = new Frame(f4     , randomTransform(random), "f5");
        Frame f6 = new Frame(eme2000, randomTransform(random), "f6");
        Frame f7 = new Frame(f6     , randomTransform(random), "f7");
        Frame f8 = new Frame(f6     , randomTransform(random), "f8");
        Frame f9 = new Frame(f7     , randomTransform(random), "f9");

        // check if the root frame can be an ancestor of another frame
        Assert.assertEquals(false, eme2000.isChildOf(f5));

        // check if a frame which belongs to the same branch than the 2nd frame is a branch of it
        Assert.assertEquals(true, f5.isChildOf(f1));

        // check if a random frame is the child of the root frame 
        Assert.assertEquals(true, f9.isChildOf(eme2000));

        // check that a frame is not its own child
        Assert.assertEquals(false, f4.isChildOf(f4));

        // check if a frame which belong to a different branch than the 2nd frame can be a child for it
        Assert.assertEquals(false, f9.isChildOf(f5));

        // check if the root frame is not a child of itself
        Assert.assertEquals(false, eme2000.isChildOf(eme2000));

        Assert.assertEquals(false, f9.isChildOf(f8));

    }

    @Test
    public void testUpdateTransform() throws OrekitException {
        Random random     = new Random(0x2f6769c23e53e96el);
        Frame eme2000     = FramesFactory.getEME2000();
        AbsoluteDate date = new AbsoluteDate();

        Frame f1 = new Frame(eme2000, randomTransform(random), "f1");
        Frame f2 = new Frame(f1     , randomTransform(random), "f2");
        Frame f3 = new Frame(f2     , randomTransform(random), "f3");
        Frame f4 = new Frame(f2     , randomTransform(random), "f4");
        Frame f5 = new Frame(f4     , randomTransform(random), "f5");
        Frame f6 = new Frame(eme2000, randomTransform(random), "f6");
        Frame f7 = new Frame(f6     , randomTransform(random), "f7");
        Frame f8 = new Frame(f6     , randomTransform(random), "f8");
        Frame f9 = new Frame(f7     , randomTransform(random), "f9");

        checkFrameAncestorException(f6, f8, f9, randomTransform(random), date);
        checkFrameAncestorException(f6, f3, f5, randomTransform(random), date);
        checkFrameAncestorException(eme2000, f5, f9, randomTransform(random), date);
        checkFrameAncestorException(f3, eme2000, f6, randomTransform(random), date);    

        checkUpdateTransform(f1, f5, f9, date, random);
        checkUpdateTransform(f7, f6, f9, date, random);
        checkUpdateTransform(f6, eme2000, f7, date, random);

        checkUpdateTransform(f6, f6.getParent(), f6, date, random);

    }

    private void checkFrameAncestorException(Frame f0, Frame f1, Frame f2,
                                             Transform transform, AbsoluteDate date) {
        doCheckFrameAncestorException(f0, f1, f2, transform, date);
        doCheckFrameAncestorException(f0, f2, f1, transform, date);
    }

    private void doCheckFrameAncestorException(Frame f0, Frame f1, Frame f2,
                                               Transform transform, AbsoluteDate date) {
        try {
            f0.updateTransform(f1, f2, transform, date);
            Assert.fail("Should raise a FrameAncestorException");
        } catch(FrameAncestorException expected){
            // expected behavior
        } catch (Exception e) {
            Assert.fail("wrong exception caught");
        }
    }

    private void checkUpdateTransform(Frame f0, Frame f1, Frame f2,
                                      AbsoluteDate date, Random random)
      throws OrekitException {
        Transform f1ToF2 = randomTransform(random);

        f0.updateTransform(f1, f2, f1ToF2, date);
        Transform obtained12 = f1.getTransformTo(f2, date);
        checkNoTransform(new Transform(f1ToF2, obtained12.getInverse()), random);

        f0.updateTransform(f2, f1, f1ToF2.getInverse(), date);
        Transform obtained21 = f2.getTransformTo(f1, date);
        checkNoTransform(new Transform(f1ToF2.getInverse(), obtained21.getInverse()), random);

        checkNoTransform(new Transform(obtained12, obtained21), random);

    }

    private Transform randomTransform(Random random) {
        Transform transform = Transform.IDENTITY;
        for (int i = random.nextInt(10); i > 0; --i) {
            if (random.nextBoolean()) {
                Vector3D u = new Vector3D(random.nextDouble() * 1000.0,
                                          random.nextDouble() * 1000.0,
                                          random.nextDouble() * 1000.0);
                transform = new Transform(transform, new Transform(u));
            } else {
                double q0 = random.nextDouble() * 2 - 1;
                double q1 = random.nextDouble() * 2 - 1;
                double q2 = random.nextDouble() * 2 - 1;
                double q3 = random.nextDouble() * 2 - 1;
                double q  = Math.sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3);
                Rotation r = new Rotation(q0 / q, q1 / q, q2 / q, q3 / q, false);
                transform = new Transform(transform, new Transform(r));
            }
        }
        return transform;
    }

    private void checkNoTransform(Transform transform, Random random) {
        for (int i = 0; i < 100; ++i) {
            Vector3D a = new Vector3D(random.nextDouble(),
                                      random.nextDouble(),
                                      random.nextDouble());
            Vector3D b = transform.transformVector(a);
            Assert.assertEquals(0, a.subtract(b).getNorm(), 1.0e-10);
            Vector3D c = transform.transformPosition(a);
            Assert.assertEquals(0, a.subtract(c).getNorm(), 1.0e-10);
        }
    }

    @Before
    public void setUp() {
        Utils.setDataRoot("compressed-data");
    }

}
