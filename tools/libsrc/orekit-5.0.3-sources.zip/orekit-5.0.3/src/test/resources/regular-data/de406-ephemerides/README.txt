The file in this directory is a test file only.
It should NOT be used for anything but test purposes.

The Chebyshev coefficients are real ones extracted from the official
JPL file unxp2700.406, but the header has been edited and the file
has been truncated for test purposes.

The original files can be found on the JPL FTP server:
  ftp://ssd.jpl.nasa.gov/pub/eph/planets/unix/de406
